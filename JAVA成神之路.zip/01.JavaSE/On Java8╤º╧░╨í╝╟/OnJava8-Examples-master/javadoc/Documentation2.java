// javadoc/Documentation2.java
// (c)2020 MindView LLC: see Copyright.txt
// We make no guarantees that this code is fit for any purpose.
// Visit http://OnJava8.com for more book information.
/** <pre>
 * System.out.println(new Date());
 * </pre>
 */
public class Documentation2 {}
